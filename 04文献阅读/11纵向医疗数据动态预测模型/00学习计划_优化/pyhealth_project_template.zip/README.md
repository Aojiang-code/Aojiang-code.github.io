# PyHealth 医学纵向预测项目模板

本项目使用 PyHealth 构建以 MIMIC 为基础的医学预测任务（如 AKI 预测）。