# 06_evaluate_model.py - 填写此脚本以完成对应功能

