# 07_attention_analysis.py - 填写此脚本以完成对应功能

