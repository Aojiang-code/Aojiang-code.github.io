# 08_compare_models.py - 填写此脚本以完成对应功能

