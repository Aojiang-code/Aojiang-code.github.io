# 04_define_task.py - 填写此脚本以完成对应功能

