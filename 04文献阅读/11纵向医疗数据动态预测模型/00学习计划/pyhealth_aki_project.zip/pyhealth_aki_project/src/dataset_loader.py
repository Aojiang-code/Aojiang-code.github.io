import pandas as pd
from pyhealth.datasets import PatientDataset

def load_aki_dataset(csv_path: str) -> PatientDataset:
    df = pd.read_csv(csv_path, parse_dates=["date"])
    df = df.sort_values(["patient_id", "date"])

    data = []
    for idx, row in df.iterrows():
        visit = {
            "patient_id": row["patient_id"],
            "encounter_id": f"{row['patient_id']}_v{idx}",
            "timestamp": row["date"],
            "events": {
                "creatinine": row["creatinine"],
                "bun": row["bun"],
                "egfr": row["egfr"]
            },
            "label": int(row["label"])
        }
        data.append(visit)

    dataset = PatientDataset(name="aki_dataset", data=data)
    return dataset