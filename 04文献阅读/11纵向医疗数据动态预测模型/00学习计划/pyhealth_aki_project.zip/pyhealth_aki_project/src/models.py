from pyhealth.models import LSTMModel, GRUDModel, RETAINModel

def get_model(model_name, task, hidden_size=64):
    if model_name == "lstm":
        return LSTMModel(task=task, hidden_size=hidden_size)
    elif model_name == "grud":
        return GRUDModel(task=task, hidden_size=hidden_size)
    elif model_name == "retain":
        return RETAINModel(task=task, hidden_size=hidden_size)
    else:
        raise ValueError("Unsupported model")