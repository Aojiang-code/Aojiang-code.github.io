from pyhealth.trainer import Trainer
from pyhealth.metrics import calc_metrics

def train_model(model, task, epochs=10, batch_size=4, lr=1e-3):
    train_ds, val_ds = task.split(0.8)
    trainer = Trainer(
        model=model,
        train_dataset=train_ds,
        val_dataset=val_ds,
        epochs=epochs,
        batch_size=batch_size,
        optimizer_params={"lr": lr},
        metrics=["acc", "auc", "f1"]
    )
    trainer.train()
    metrics = calc_metrics(model, val_ds, metrics=["acc", "auc", "f1", "precision", "recall"])
    return model, metrics