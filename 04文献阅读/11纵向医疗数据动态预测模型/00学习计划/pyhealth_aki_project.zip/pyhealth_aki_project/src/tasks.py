from pyhealth.tasks import BinaryPredictionTask

def build_aki_task(dataset):
    task = BinaryPredictionTask(
        dataset=dataset,
        feature_keys=["creatinine", "bun", "egfr"],
        label_key="label",
        time_order=True
    )
    return task