from src.dataset_loader import load_aki_dataset
from src.tasks import build_aki_task
from src.models import get_model
from src.train import train_model
import torch

dataset = load_aki_dataset("data/aki_labs.csv")
task = build_aki_task(dataset)
model = get_model("retain", task)
model, metrics = train_model(model, task)
print("Final metrics:", metrics)
torch.save(model.state_dict(), "checkpoints/retain_model.pt")